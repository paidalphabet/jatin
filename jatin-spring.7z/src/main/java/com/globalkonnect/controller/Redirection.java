package com.globalkonnect.controller;

public interface Redirection {
	
	public static final String ABOUT_US = "global-konnect/about-us";
	public static final String INDEX = "index";
	public static final String PLANS = "global-konnect/plans";

}
