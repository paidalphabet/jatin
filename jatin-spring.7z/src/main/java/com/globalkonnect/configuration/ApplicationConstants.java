package com.globalkonnect.configuration;

public interface ApplicationConstants {

	public final static String EMAIL_ACC_USERNAME = "postmaster@wisegoals.in";
	public final static String EMAIL_ACC_PASSWORD = "Jericho@123";
	public final static String EMAIL_ACC_SMTP_HOST = "smtp.mailgun.org";
	public final static String EMAIL_ACC_ID = "yourwisegoals@gmail.com";

	public final static String GOAL_SAVED = "GOALSAVED";
	public final static String GOAL_SAVED_YES = "YES";
	public final static String GOAL_SAVED_NO = "NO";

	public final static String PASSWORD_CHANGE = "PASSWORD_CHANGE";
	public final static String PASSWORD_CHANGE_Y = "Y";
	public final static String PASSWORD_CHANGE_N = "N";

	public static final boolean LOG_REQUESTS = false;

}
